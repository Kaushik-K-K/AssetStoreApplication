package com.example.assetstore.model;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Component
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Getter
@Setter
public class StoreDetails {
	@Id
	private long storeid;
	
	private long storevalue;
	
	@JsonIgnore
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private Date createddate;
	
	@JsonIgnore
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private Date modifieddate;	

}
