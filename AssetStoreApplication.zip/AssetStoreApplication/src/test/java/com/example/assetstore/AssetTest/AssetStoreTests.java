package com.example.assetstore.AssetTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.SpringApplication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import static org.mockito.BDDMockito.willDoNothing;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.example.assetstore.AssetStoreApplication;
import com.example.assetstore.dao.AssetService;
import com.example.assetstore.exception.DataFormatException;
import com.example.assetstore.exception.NotFoundException;
import com.example.assetstore.model.AssetDetails;
import com.example.assetstore.model.Role;
import com.example.assetstore.model.StoreDetails;
import com.example.assetstore.model.User;
import com.example.assetstore.repository.AssetRepository;
import com.example.assetstore.repository.UserRepository;
import com.example.assetstore.security.CustomUserDetailsService;

import static org.mockito.BDDMockito.given;

@ExtendWith(MockitoExtension.class)
class AssetStoreTests {
	@Mock
	private AssetRepository assetrep;

	@InjectMocks
	private AssetService assetserv;

	private AssetDetails assetdet;

	private AssetDetails assetdet1;

	@Mock
	private UserRepository userrep;

	@InjectMocks
	private CustomUserDetailsService serv;

	private User user;

	@BeforeEach
	public void setup() throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date yourDate = sdf.parse("2022-04-03");
		Date yourDate1 = sdf.parse("2022-04-05");

		List<StoreDetails> store = new ArrayList<StoreDetails>();
		StoreDetails storedet = new StoreDetails(2001, 60000, yourDate, yourDate1);
		StoreDetails sto = new StoreDetails(2002, 70000, yourDate, yourDate1);
		store.add(storedet);
		store.add(sto);

		assetdet = AssetDetails.builder().id(1001L).assetname("DeLLLaptop").storedetails(store).createddate(yourDate)
				.modifieddate(yourDate1).build();
		assetdet1 = AssetDetails.builder().id(1002L).assetname("SamsungMobile").storedetails(store)
				.createddate(yourDate).modifieddate(yourDate1).build();

		Set<Role> role = new HashSet<Role>();
		Role roles = new Role(1, "ROLE_USER");
		role.add(roles);
		user = User.builder().id(1).name("Sapthami").username("sap").email("sap@gmail.com").password("password")
				.roles(role).build();
	}

	@Test
	public void addAssetDetailsTest() throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date yourDate = sdf.parse("2022-04-03");
		Date yourDate1 = sdf.parse("2022-04-05");
		List<StoreDetails> store = new ArrayList<StoreDetails>();
		StoreDetails storedet = new StoreDetails(2001, 60000, yourDate, yourDate1);
		StoreDetails sto = new StoreDetails(2002, 70000, yourDate, yourDate1);
		store.add(storedet);
		store.add(sto);

		assetdet = AssetDetails.builder().id(1001L).assetname("DeLLLaptop").storedetails(store).createddate(yourDate)
				.modifieddate(yourDate1).build();
		assetdet1 = AssetDetails.builder().id(1002L).assetname("SamsungMobile").storedetails(store)
				.createddate(yourDate).modifieddate(yourDate1).build();
		given(assetrep.save(assetdet)).willReturn(assetdet);
		AssetDetails savedasset = assetserv.addAssetDetails(assetdet);
		assertThat(savedasset).isNotNull();

	}

	@Test

	public void getAllAssetTest() throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date yourDate = sdf.parse("2022-04-03");
		Date yourDate1 = sdf.parse("2022-04-05");

		List<StoreDetails> store = new ArrayList<StoreDetails>();
		StoreDetails storedet = new StoreDetails(2001, 60000, yourDate, yourDate1);
		StoreDetails sto = new StoreDetails(2002, 70000, yourDate, yourDate1);
		store.add(storedet);
		store.add(sto);

		assetdet = AssetDetails.builder().id(1001L).assetname("DeLLLaptop").storedetails(store).createddate(yourDate)
				.modifieddate(yourDate1).build();
		assetdet1 = AssetDetails.builder().id(1002L).assetname("SamsungMobile").storedetails(store)
				.createddate(yourDate).modifieddate(yourDate1).build();
		given(assetrep.findAll()).willReturn(List.of(assetdet, assetdet1));
		List<AssetDetails> assetlist = assetserv.getAllAsset();
// assertThat(assetlist).isNotNull();
		assertThat(assetlist.size()).isEqualTo(2);

	}

	@Test
	public void getByIdNotFound() throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date yourDate = sdf.parse("2022-04-03");
		Date yourDate1 = sdf.parse("2022-04-05");

		List<StoreDetails> store = new ArrayList<StoreDetails>();
		StoreDetails storedet = new StoreDetails(2001, 60000, yourDate, yourDate1);
		StoreDetails sto = new StoreDetails(2002, 70000, yourDate, yourDate1);
		store.add(storedet);
		store.add(sto);

		assetdet = AssetDetails.builder().id(1001L).assetname("DeLLLaptop").storedetails(store).createddate(yourDate)
				.modifieddate(yourDate1).build();
		assetdet1 = AssetDetails.builder().id(1002L).assetname("SamsungMobile").storedetails(store)
				.createddate(yourDate).modifieddate(yourDate1).build();
		given(assetrep.findById(1001L)).willReturn(Optional.empty());
		assertThatExceptionOfType(DataFormatException.class).isThrownBy(() -> assetserv.getAssetById(1001L))
				.withMessage("ID is not available").withNoCause();

	}

	@Test

	public void getAssetByIdTest() throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date yourDate = sdf.parse("2022-04-03");
		Date yourDate1 = sdf.parse("2022-04-05");

		List<StoreDetails> store = new ArrayList<StoreDetails>();
		StoreDetails storedet = new StoreDetails(2001, 60000, yourDate, yourDate1);
		StoreDetails sto = new StoreDetails(2002, 70000, yourDate, yourDate1);
		store.add(storedet);
		store.add(sto);

		assetdet = AssetDetails.builder().id(1001L).assetname("DeLLLaptop").storedetails(store).createddate(yourDate)
				.modifieddate(yourDate1).build();
		assetdet1 = AssetDetails.builder().id(1002L).assetname("SamsungMobile").storedetails(store)
				.createddate(yourDate).modifieddate(yourDate1).build();
		given(assetrep.findById(1001L)).willReturn(Optional.of(assetdet));
		AssetDetails foundasset = assetserv.getAssetById(assetdet.getId()).get();
		assertThat(foundasset).isNotNull();

	}

	@Test
	public void UpdateAssetNotFound() throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date yourDate = sdf.parse("2022-04-03");
		Date yourDate1 = sdf.parse("2022-04-05");

		List<StoreDetails> store = new ArrayList<StoreDetails>();
		StoreDetails storedet = new StoreDetails(2001, 60000, yourDate, yourDate1);
		StoreDetails sto = new StoreDetails(2002, 70000, yourDate, yourDate1);
		store.add(storedet);
		store.add(sto);

		assetdet = AssetDetails.builder().id(1001L).assetname("DeLLLaptop").storedetails(store).createddate(yourDate)
				.modifieddate(yourDate1).build();
		assetdet1 = AssetDetails.builder().id(1002L).assetname("SamsungMobile").storedetails(store)
				.createddate(yourDate).modifieddate(yourDate1).build();
		given(assetrep.findById(assetdet.getId())).willReturn(Optional.empty());
		assertThatExceptionOfType(NotFoundException.class).isThrownBy(() -> assetserv.updateAssetStore(assetdet))
				.withMessage("Not Exists").withNoCause();

	}

	@Test

	public void updateAssetTest() throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date yourDate = sdf.parse("2022-04-03");
		Date yourDate1 = sdf.parse("2022-04-05");

		List<StoreDetails> store = new ArrayList<StoreDetails>();
		StoreDetails storedet = new StoreDetails(2001, 60000, yourDate, yourDate1);
		StoreDetails sto = new StoreDetails(2002, 70000, yourDate, yourDate1);
		store.add(storedet);
		store.add(sto);

		assetdet = AssetDetails.builder().id(1001L).assetname("DeLLLaptop").storedetails(store).createddate(yourDate)
				.modifieddate(yourDate1).build();
		assetdet1 = AssetDetails.builder().id(1002L).assetname("SamsungMobile").storedetails(store)
				.createddate(yourDate).modifieddate(yourDate1).build();
		given(assetrep.findById(assetdet1.getId())).willReturn(Optional.of(assetdet1));
		given(assetrep.getById(1002L)).willReturn(assetdet1);
		assetdet1.setAssetname("HeadPhone");
		given(assetrep.save(assetdet1)).willReturn(assetdet1);
		AssetDetails assetdet3 = assetserv.updateAssetStore(assetdet1);
		assertThat(assetdet3).isEqualTo(assetdet1);

	}

	@Test
	public void deleteAssetNotFound() {
		long assetId = 1001L;
		given(assetrep.findById(assetId)).willReturn(Optional.empty());
		assertThatExceptionOfType(NotFoundException.class).isThrownBy(() -> assetserv.deleteAsset(assetId))
				.withMessage("Not Exists").withNoCause();

	}

	@Test
	public void deleteAssetTest() throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date yourDate = sdf.parse("2022-04-03");
		Date yourDate1 = sdf.parse("2022-04-05");

		List<StoreDetails> store = new ArrayList<StoreDetails>();
		StoreDetails storedet = new StoreDetails(2001, 60000, yourDate, yourDate1);
		StoreDetails sto = new StoreDetails(2002, 70000, yourDate, yourDate1);
		store.add(storedet);
		store.add(sto);

		assetdet = AssetDetails.builder().id(1001L).assetname("DeLLLaptop").storedetails(store).createddate(yourDate)
				.modifieddate(yourDate1).build();
		assetdet1 = AssetDetails.builder().id(1002L).assetname("SamsungMobile").storedetails(store)
				.createddate(yourDate).modifieddate(yourDate1).build();
		long assetId = 1001L;
		given(assetrep.findById(assetId)).willReturn(Optional.of(assetdet));
		willDoNothing().given(assetrep).deleteById(assetId);
		assetserv.deleteAsset(assetId);
		verify(assetrep, times(1)).deleteById(assetId);
	}

	@Test
	public void loaduserbyusernametest() {
		Set<Role> role = new HashSet<Role>();
		Role roles = new Role(1, "ROLE_USER");
		role.add(roles);
		user = User.builder().id(1).name("Sapthami").username("sap").email("sap@gmail.com").password("password")
				.roles(role).build();
		given(userrep.findByUsernameOrEmail("sap@gmail.com", "sap@gmail.com")).willReturn(Optional.of(user));
		UserDetails userdetails = serv.loadUserByUsername("sap@gmail.com");
		assertThat(userdetails).isNotNull();

	}

	@Test
	public void loadUserByUsernameNotFound() {
		given(userrep.findByUsernameOrEmail("sap@gmail.com", "sap@gmail.com")).willReturn(Optional.empty());
		assertThatExceptionOfType(UsernameNotFoundException.class)
				.isThrownBy(() -> serv.loadUserByUsername("sap@gmail.com"))
				.withMessage("User not found with username or email:sap@gmail.com").withNoCause();
	}

}